package integration;

import model.Sale;

public class AccountingSystem {
    public AccountingSystem() {

    }

    public void saveSaleInformation(Sale sale) {

    }
}
